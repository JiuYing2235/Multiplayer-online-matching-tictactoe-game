﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Collections.Generic;

namespace server
{
    class Server
    {
        static Dictionary<string, string> players = new Dictionary<string, string>();
        static Dictionary<string, GameRecord> gameRecords = new Dictionary<string, GameRecord>();
        static object lockObj = new object();

        static void Main(string[] args)
        {
            Console.WriteLine("Server starting!");

            IPAddress ipAddr = IPAddress.Any;
            int port = 11000;

            TcpListener listener = new TcpListener(ipAddr, port);
            listener.Start();

            while (true)
            {
                TcpClient client = listener.AcceptTcpClient();
                ThreadPool.QueueUserWorkItem(HandleClient, client);
            }
        }

        static void HandleClient(object state)
        {
            TcpClient client = (TcpClient)state;
            IPEndPoint clientEndPoint = (IPEndPoint)client.Client.RemoteEndPoint;
            Console.WriteLine($"Connection established with client: {clientEndPoint.Address}:{clientEndPoint.Port}");

            NetworkStream stream = client.GetStream();
            StringBuilder requestBuilder = new StringBuilder();

            byte[] buffer = new byte[1024];
            int bytesRead;
            bool isEndOfRequest = false;

            while (!isEndOfRequest && (bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
            {
                string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                requestBuilder.Append(data);

                if (requestBuilder.ToString().Contains("\r\n"))
                {
                    isEndOfRequest = true;
                }
            }

            string request = requestBuilder.ToString();
            string response = ProcessRequest(request, clientEndPoint);

            byte[] responseBuffer = Encoding.ASCII.GetBytes(response);

            // Add CORS headers to allow requests from any origin
            string headers = "HTTP/1.1 200 OK\r\n" +
                             "Access-Control-Allow-Origin: *\r\n" +
                             "Access-Control-Allow-Methods: GET\r\n" +
                             "Access-Control-Allow-Headers: Content-Type\r\n" +
                             "Content-Length: " + responseBuffer.Length + "\r\n" +
                             "\r\n";

            byte[] headersBuffer = Encoding.ASCII.GetBytes(headers);

            // Write the headers followed by the response data
            stream.Write(headersBuffer, 0, headersBuffer.Length);
            stream.Write(responseBuffer, 0, responseBuffer.Length);

            if (ShouldKeepConnectionOpen(request))
            {
                // Flush the stream to ensure the response is sent immediately
                stream.Flush();

                // Continue reading and processing additional requests
                HandleClient(client);
            }
            else
            {
                stream.Close();
                client.Close();
            }
        }

        static bool ShouldKeepConnectionOpen(string request)
        {
            // Check if the request contains a specific header or parameter
            // Modify this logic according to your requirements
            return true;
        }

        static string ProcessRequest(string request, IPEndPoint clientEndPoint)
        {
            string[] tokens = request.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (tokens.Length < 2 || tokens[0] != "GET")
            {
                return "HTTP/1.1 400 Bad Request\r\n\r\n";
            }

            string url = tokens[1];
            Console.WriteLine($"Client accessed URL: {url} - Thread ID: {Thread.CurrentThread.ManagedThreadId}");

            if (url == "/register")
            {
                string username = GenerateUsername();
                lock (lockObj)
                {
                    if (players.ContainsKey(clientEndPoint.ToString()))
                    {
                        players[clientEndPoint.ToString()] = username; // Update existing username
                    }
                    else
                    {
                        players.Add(clientEndPoint.ToString(), username); // Add new username
                    }
                }
                return $"\r\n{username}\r\n";
            }
            else if (url.StartsWith("/pairme?player="))
            {
                string playerName = GetParameter(url, "player");
                string gameRecordId = FindWaitingGameRecord(playerName);

                if (gameRecordId == null)
                {
                    Random random = new Random();
                    gameRecordId = random.Next(1000, 9999).ToString();

                    GameRecord gameRecord = new GameRecord(gameRecordId, playerName, "wait");
                    lock (lockObj)
                    {
                        gameRecords.Add(gameRecordId, gameRecord);
                    }
                    return $"\r\n{gameRecord.ToString()}\r\n";
                }
                else
                {
                    GameRecord gameRecord;
                    lock (lockObj)
                    {
                        gameRecord = gameRecords[gameRecordId];
                        gameRecord.SecondPlayer = playerName;
                        gameRecord.State = "progress";
                    }
                    return $"\r\n{gameRecord.ToString()}\r\n";
                }
            }
            else if (url.StartsWith("/mymove?player="))
            {
                string playerName = GetParameter(url, "player");
                string gameId = GetParameter(url, "id");
                string move = GetParameter(url, "move");
                GameRecord gameRecord;
                lock (lockObj)
                {
                    if (!gameRecords.ContainsKey(gameId))
                    {
                        return "\r\nHTTP/1.1 404 Not Found\r\n\r\n";
                    }
                    gameRecord = gameRecords[gameId];
                    if (gameRecord.State != "progress")
                    {
                        return "\r\nHTTP/1.1 400 Bad Request\r\n\r\n";
                    }
                    if (playerName == gameRecord.FirstPlayer)
                    {
                        gameRecord.LastMovePlayer1 = move;
                    }
                    else if (playerName == gameRecord.SecondPlayer)
                    {
                        gameRecord.LastMovePlayer2 = move;
                    }
                }
                return $"\r\n{gameRecord.ToString()}\r\n";
            }

            else if (url.StartsWith("/theirmove?player="))
            {
                string playerName = GetParameter(url, "player");
                string gameId = GetParameter(url, "id");
                GameRecord gameRecord;
                lock (lockObj)
                {
                    if (!gameRecords.ContainsKey(gameId))
                    {
                        return "\r\nHTTP/1.1 404 Not Found\r\n\r\n";
                    }
                    gameRecord = gameRecords[gameId];
                    if (gameRecord.State != "progress" || (playerName != gameRecord.FirstPlayer && playerName != gameRecord.SecondPlayer))
                    {
                        return "\r\nHTTP/1.1 400 Bad Request\r\n\r\n";
                    }
                }
                string lastMove;
                if (playerName == gameRecord.FirstPlayer)
                {
                    lastMove = gameRecord.LastMovePlayer2;
                }
                else
                {
                    lastMove = gameRecord.LastMovePlayer1;
                }
                return $"\r\n{lastMove}\r\n";
            }

            else if (url.StartsWith("/quit?player="))
            {
                string playerName = GetParameter(url, "player");
                string gameId = GetParameter(url, "id");

                lock (lockObj)
                {
                    if (gameRecords.ContainsKey(gameId))
                    {
                        GameRecord gameRecord = gameRecords[gameId];

                        // Check if the player is a participant in the game
                        if (playerName == gameRecord.FirstPlayer || playerName == gameRecord.SecondPlayer)
                        {
                            gameRecords.Remove(gameId);
                            return "\r\nHTTP/1.1 200 OK\r\n\r\n";
                        }
                        else
                        {
                            return "\r\nHTTP/1.1 403 Forbidden\r\n\r\n";
                        }
                    }
                    else
                    {
                        return "\r\nHTTP/1.1 404 Not Found\r\n\r\n";
                    }
                }
            }
            else
            {
                return "\r\nHTTP/1.1 404 Not Found\r\n\r\n";
            }
        }

        static string GetParameter(string url, string paramName)
        {
            int index = url.IndexOf(paramName + "=");
            if (index == -1)
                return null;

            int startIndex = index + paramName.Length + 1;
            int endIndex = url.IndexOf("&", startIndex);
            if (endIndex == -1)
                endIndex = url.Length;

            return url.Substring(startIndex, endIndex - startIndex);
        }

        static string GenerateUsername()
        {
            Random random = new Random();
            string username;
            bool isUnique = false;

            do
            {
                username = "Player" + random.Next(1000, 9999).ToString();

                lock (lockObj)
                {
                    if (!players.ContainsValue(username))
                    {
                        isUnique = true;
                    }
                }
            } while (!isUnique);

            return username;
        }

        static string FindWaitingGameRecord(string playerName)
        {
            foreach (var gameRecord in gameRecords.Values)
            {
                if (gameRecord.State == "wait")
                {
                    return gameRecord.GameId;
                }
            }
            return null;
        }

        class GameRecord
        {
            public string GameId { get; }
            public string FirstPlayer { get; }
            public string SecondPlayer { get; set; }
            public string State { get; set; }
            public string LastMovePlayer1 { get; set; }
            public string LastMovePlayer2 { get; set; }
            public GameRecord(string gameId, string firstPlayer, string state)
            {
                GameId = gameId;
                FirstPlayer = firstPlayer;
                State = state;
            }
            public override string ToString()
            {
                return $"{{ \"gameId\": \"{GameId}\", \"state\": \"{State}\", \"firstPlayer\": \"{FirstPlayer}\", \"secondPlayer\": \"{SecondPlayer}\", \"lastMovePlayer1\": \"{LastMovePlayer1}\", \"lastMovePlayer2\": \"{LastMovePlayer2}\" }}";
            }
        }
    }
}
