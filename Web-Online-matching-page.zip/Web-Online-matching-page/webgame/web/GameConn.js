window.onload = function() {
    let username = null;
    let gameId = null;
    let messageArea = document.getElementById("messageArea");
    let theirmoveId = null;
    var origBoard;
    let currentPlayer = null;
    let theOtherPlayer = null;
    let firstPlayer = null;
    let secondPlayer = null;
    const winCombos = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8],
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8],
        [0, 4, 8],
        [6, 4, 2]
    ]

    function showMessage(message) {
        var p = document.createElement("p");
        p.innerHTML = message;
        messageArea.appendChild(p);
        messageArea.scrollTop = messageArea.scrollHeight;
    }

    function markMove(cellId) {
        if (!username || !gameId) {
            showMessage("Please register and match first");
            return;
        }
        const move = cellId;
        fetch(`http://localhost:11000/mymove?player=${username}&id=${gameId}&move=${move}`, { method: 'GET', mode: 'cors' })
            .then(response => response.text())
            .then(data => {
                showMessage(data);
            });
    }


    document.getElementById('registerBtn').addEventListener('click', function() {
        register();
    });

    document.getElementById('matchBtn').addEventListener('click', function() {
        pair();
    });

    document.getElementById('theirmoveBtn').addEventListener('click', function() {
        theirmove();
    });

    document.getElementById('quitBtn').addEventListener('click', function() {
        quit();
    });

    function register() {
        fetch('http://localhost:11000/register', { method: 'GET', mode: 'cors' })
            .then(response => response.text())
            .then(data => {
                username = data.trim();
                showMessage("Registered successfully, user name: " + username);
            });
    }

    function pair() {
        if (!username) {
            showMessage("Register for Account");
            return;
        }
        fetch(`http://localhost:11000/pairme?player=${username}`, { method: 'GET', mode: 'cors' })
            .then(response => response.text())
            .then(data => {
                const gameData = JSON.parse(data);
                gameId = gameData.gameId;
                firstPlayer = gameData.firstPlayer;
                secondPlayer = gameData.secondPlayer;
                if (username == firstPlayer) {
                    currentPlayer = 'O';
                    theOtherPlayer = 'X';
                }
                if (username == secondPlayer) {
                    currentPlayer = 'X';
                    theOtherPlayer = 'O';
                }
                showMessage("GET Game ID: " + gameId);
            });
    }

    function theirmove() {
        if (!username || !gameId) {
            showMessage("Please register and match first");
            return;
        }
        fetch(`http://localhost:11000/theirmove?player=${username}&id=${gameId}`, { method: 'GET', mode: 'cors' })
            .then(response => response.text())
            .then(data => {
                theirmoveId = parseInt(data);
                showMessage("Opponent's move: " + theirmoveId);
                if (username == firstPlayer){
                    theirturn(theirmoveId, theOtherPlayer, secondPlayer);
                }
                if (username == secondPlayer){
                    theirturn(theirmoveId, theOtherPlayer, firstPlayer);
                }
            });
    }

    function quit() {
        if (!username || !gameId) {
            showMessage("Please register and match first");
            return;
        }
        fetch(`http://localhost:11000/quit?player=${username}&id=${gameId}`, { method: 'GET', mode: 'cors' })
            .then(response => response.text())
            .then(data => {
                showMessage(data);
                username = null;
                gameId = null;
            });
    }


    /*Getting Elements*/
    const cells = document.querySelectorAll(".cell");

    startGame();

    function startGame () {
        document.querySelector(".endgame").style.display = "none";
        //Set Array point creates 9 array elements with keys 0 through 8
        origBoard = Array.from(Array(9).keys());
        for (var i = 0; i < cells.length; i++) {
            cells[i].innerHTML = "";
            cells[i].style.removeProperty('background-color');
            //click the Blocks
            cells[i].addEventListener('click', turnClick, false);
        }
    }

    function turnClick(square) {
        if (typeof origBoard[square.target.id] == 'number') {
            turn(square.target.id, currentPlayer, username);
            markMove(square.target.id);
        }
    }

    function turn (squareId, player, whichplayer) {
        origBoard[squareId] = whichplayer;
        document.getElementById(squareId).innerHTML = player;
        //check
        var gameWin = checkWin(origBoard, whichplayer);
        if (gameWin) {
            gameOver(gameWin);
        }
    }

    function theirturn (squareId, player, whichplayer) {
        origBoard[squareId] = whichplayer;
        document.getElementById(squareId).innerHTML = player;
        //check
        var gameWin = checkWin(origBoard, whichplayer);
        if (gameWin) {
            gameOver(gameWin);
        }
    }
    //Judge winner
    function checkWin (board, player) {
        let plays = board.reduce((a, e, i) =>
            (e === player) ? a.concat(i) : a, [])
        let gameWin = null;
        for (let [index, win] of winCombos.entries()) {
            if (win.every(Element => plays.indexOf(Element) > -1)) {
                gameWin = { index: index, player: player };
                break;
            }
        }
        return gameWin;
    }
    /*game over*/
    function gameOver (gameWin) {
        for (let index of winCombos[gameWin.index]) {
            document.getElementById(index).style.backgroundColor =
                gameWin.player == username ? "blue" : "red";
        }
        for (var i = 0; i < cells.length; i++) {
            cells[i].removeEventListener('click', turnClick, false);
        }
        declareWinner(gameWin.player == username ? "You win!!!" : "You lose!!!");
    }

    function declareWinner (who) {
        document.querySelector(".endgame").style.display = 'block';
        document.querySelector(".endgame .text").innerHTML = who;
    }
};
